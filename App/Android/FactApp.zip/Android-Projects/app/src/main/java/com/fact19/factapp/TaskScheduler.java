package com.fact19.factapp;

public class TaskScheduler {

    public void reScheduleTask(int interval) {

    }


}
