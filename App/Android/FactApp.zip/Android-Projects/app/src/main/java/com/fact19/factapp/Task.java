package com.fact19.factapp;

import java.util.TimerTask;

public class Task extends TimerTask {

    @Override
    public void run() {

    }



}
